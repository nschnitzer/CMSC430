#!/bin/bash

rm example_test.run
make example_test.run
./example_test.run
