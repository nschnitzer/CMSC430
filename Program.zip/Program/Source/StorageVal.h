/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * StorageVal
 * Stores imageNum, preperiod, and period information.  This is meant to
 * be stored in some structure according to a StorageKey.
 *
 * Written by: Bryant Lee
 * Date: 11/4/04
 */

#ifndef STORAGE_VAL_H
#define STORAGE_VAL_H

#define byte unsigned char

class StorageVal {
 public:
  int imageNum;
  unsigned int preperiod, period;

 public:
  StorageVal(int iNum);
  
};

#endif
