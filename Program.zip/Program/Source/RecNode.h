/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * RecNode
 * A record node.  Stores information for all the runs for a given period.
 *
 * Written by: Bryant Lee
 * Date: 11/4/04
 */

#ifndef REC_NODE_H
#define REC_NODE_H

#include <map>

class RecNode {
 public:
  unsigned long long currPeriod, numPeriodic, numTrials, largestorbit;
  unsigned long long sumPeriod, sumPreperiod;

  bool pending;

  map<unsigned long long, unsigned long long> 
    periodMap, // key = eventual pd., value = # points with this pd.
    preperiodMap, // key = prepd., value = # points with this prepd.
    orbitMap, // key = pd., value = # orbits with this pd.
    periodicPeriodMap; //key = pd., value = # periodic points with this pd.

 public:
  //constructor
  RecNode(unsigned int icPeriod, unsigned long long iNumTrials);
  
  //recordOrbit
  void recordOrbit(unsigned long long iOrbit);

  //recordPeriod
  //Use this to record points with eventual period "period" and
  //preperiod "preperiod"
  void recordPeriod(unsigned long long period, unsigned long long preperiod);

  //recordPeriodicPeriod
  //Use this to record _periodic_ points with period "period"
  //This should be done in addition to recordPeriod above
  void recordPeriodicPeriod(unsigned long long period);

  //fraction periodic
  double fractionPeriodic();

  //numnonperiodic
  unsigned long long numNonPeriodic();

  //avgPeriod
  double avgPeriod();

  //avgPrePeriod
  double avgPreperiod();

  //maxpreperiod
  double maxPreperiod();

  //maxperiod
  double maxPeriod();
};

#endif
