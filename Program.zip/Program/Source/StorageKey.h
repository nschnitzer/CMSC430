/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * StorageKey
 * Node with a word member.  Comparisons are allowed and are according
 * to lexicographic order of the words.
 *
 * Written by: Bryant Lee
 * Date: 11/4/04
 */

#ifndef STORAGE_KEY_H
#define STORAGE_KEY_H

#define byte unsigned char

class StorageKey {
 public:
  byte * word;
 private:
  unsigned int wordLength;

  //compare
  //if > m, return positive
  //if < m, return negative
  //if == m, return 0
  int compareTo(const StorageKey &m) const;

 public:
  //no argument constructor
  StorageKey();

  //primary constructor
  StorageKey(byte *inWord, unsigned int inLength);

  //copy constructor
  StorageKey(const StorageKey &m);
  
  //destructor
  ~StorageKey();

  //operator =
  const StorageKey & operator=(const StorageKey &right);
 
  //relational operators
  bool operator==(const StorageKey &right) const;
  bool operator!=(const StorageKey &right) const;
  bool operator<(const StorageKey &right) const;
  bool operator>(const StorageKey &right) const;
  bool operator<=(const StorageKey &right) const;
  bool operator>=(const StorageKey &right) const;

  //print
  void print() const;

  /*
   * This hash actually puts the 0th element at the lsb, then moves left.
   * Since in the FPeriod program, 0 is actually on the left, this is
   * somewhat "backwards".
   */
  unsigned long long hash(unsigned int shiftSize) {
    unsigned int i; 
    unsigned long long result = 0;
    unsigned int power = 1;
 
    for(i = 0; i < wordLength; i++) {
      result += power * word[i];
      power *= shiftSize;
    }

    return result;
  }

  /*
   * This hash puts the 0th element at the msb and moves right.
   * Essentially, elements hash to their baseB representation where
   * B = shiftSize
   */
  unsigned long long hash_baseB(unsigned int shiftSize) {
    int i;
    unsigned long long result = 0;
    unsigned int power = 1;
    
    for(i = wordLength - 1; i >= 0; i--) {
      result += power * word[i];
      power *= shiftSize;
    }

    return result;
  }
};

#endif
