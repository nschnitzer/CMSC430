/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/* String Ops
 * Some operations that can be performed on strings
 *
 * Written by: Bryant Lee
 * Date: 10/29/04
 */

#ifndef STRING_OPS_H
#define STRING_OPS_H

#define byte unsigned char

#include <string>
#include <vector>

void split(const string &str, char c, vector<string> &output);

void trim(string &str);

//returns true if c is an upper or lower case letter
bool alphachar(char c);

//copy a byte array
void copyWord(byte *a, byte *b, unsigned int length);

void copyUIntArray(unsigned int *a, unsigned int *b, unsigned int length);

void printArray(byte *arr, unsigned int length);

void printUInt(unsigned int word, unsigned int length);

void printUIntArray(unsigned int word[], unsigned int length);

bool iterateWord(byte* arr, unsigned int length, unsigned int shiftSize);

#endif
