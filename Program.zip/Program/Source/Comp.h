/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**
 * Represents a composition of poly functions
 *
 * Written by: Bryant Lee
 * Date: 11/22/04
 **/

#ifndef COMP_H
#define COMP_H

#include "Func.h"

#include <map>
#include <vector>
#include <string>

#include <fstream> //used in printDefinitions()

class Comp {
 private:
  int shiftSize; //#symbols in shift
  map<string, Func *> funcStore; //available functions for composition
  vector<Func *> composition; //the functions in the order to apply them
  vector<string> compNames; //the composition as a list of names

  //delete Func objects whose ptrs are in the funcStore map
  void clearFuncStore();

 public:
  //constructor
  Comp(int iShiftSize);

  //destructor
  ~Comp();
  
  //returnName
  string returnName();

  //printDefinitions
  void printDefinitions(ofstream & fout);

  //print
  void print();

  //set the composition
  bool setComposition(const string & inStr);

  //add a function available for composing
  void addFunc(const string & inStr, string name, bool opt);

  //return image of word x
  void image(byte *word, int wordLength, byte *output);

  //return image of word x
  void image(unsigned int *word, int wordLength, unsigned int *output,
	     unsigned int blocks);

};

#endif




