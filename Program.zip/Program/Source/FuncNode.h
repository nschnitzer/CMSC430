/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/* FuncNode
 * Node used to represent a single piece of a function (term, operator,
 * or constant)
 *
 * Written by: Bryant Lee
 * Date: 10/29/04
 */

#ifndef FUNC_NODE_H
#define FUNC_NODE_H

#define byte unsigned char


#include <fstream> //for printing
#include <map> //for termValue_by_inputs only

class FuncNode {
 public:
  int type; // 1 = term, 2 = operator, 3 = constant
  int val; // term index, specific operator, or constant's value

  //Operator: 1 = +, 2 = -, 3 = *, 4 = ^;

  //No argument constructor
  FuncNode();

  //primary constructor
  FuncNode(int iType, int iVal);

  //copy constructor
  FuncNode(const FuncNode &m);

  //copy assignment
  const FuncNode& operator=(const FuncNode &right);

  //deepCopy
  FuncNode* deepCopy();

  //If holding a constant, returns the constant
  //If holding a term, returns the term value based on
  // the array x
  int termValue(byte *x, int wLength, int i);

  //If holding a constant, returns the constant
  //If holding a term, returns the term value based on
  // the array x
  int termValue(unsigned int *x, int wLength, int i);

  //like above except used by inputs, rather than by actual word
  int termValue_by_inputs(byte *itTerms, int numTerms,
			  const map<int,int> &optFindTerm);

  //print
  void print(ofstream & fout);
  
  //relational operators
  bool operator==(const FuncNode &right) const;
  bool operator!=(const FuncNode &right) const;
  bool operator<(const FuncNode &right) const;
  bool operator>(const FuncNode &right) const;
  bool operator<=(const FuncNode &right) const;
  bool operator>=(const FuncNode &right) const;
};

#endif


