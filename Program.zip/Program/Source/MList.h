/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FDense.
 *
 * FDense is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FDense is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * MList
 * Has the list of m-words (lexicographic and truncated) not in any jointly
 * periodic point at the current period.
 *
 * Written by: Bryant Lee
 * Date: 9/02/05
 */

#ifndef M_LIST_H
#define M_LIST_H

#include <string>

#include "StorageKey.h"

#define byte unsigned char

class MList {
 public:
  unsigned int currPeriod;
  list <string> List;

  bool pending;

 public:
  MList() {
    pending = true; //see comment below
  }

  MList(unsigned int icPeriod) {
    currPeriod = icPeriod;
    
    //This indicates that the result for this MList element is not yet valid.
    //The program flips pending to false when this MList element is filled in.
    //This is used by FDense.
    pending = true;
  };
};

#endif
