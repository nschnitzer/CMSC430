/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**
 * Represents a polynomial function in terms x[-s,t] mod N
 *
 * Written by: Bryant Lee
 * Date: 10/31/04
 **/

#ifndef FUNC_H
#define FUNC_H

#include "FuncNode.h"

#include <fstream> //for printing

#include <string>
#include <list>
#include <vector>
#include <map> //actually used only for opt polynomials

#include "StorageKey.h" //used only for opt polynomials lookup map

class Func {
 private:
  string str;
  list<FuncNode*> fList; //list representation of function (poly repres.)
  int* fTable; //lookup representation of function (table repres.)
  int shiftSize; //#symbols in shift
  int type; //0 = table, 1 = polynomial, 2= optimized polynomial
  unsigned int span; //span (table repres. only)
  unsigned int tablesize; //(table repres. only)
 
  //-- member vars used for OPT functions ONLY
  vector<int> optTerms;
  map<StorageKey, byte> optLookupMap; //takes a vector of term values, returns answer
  map<int, int> optFindTerm; //key = term #, val = coord in "compact" array
  //--

  //generates the index-th term of the image of x
  byte timage(byte *word, int wordLength, int index);
  unsigned int timage(unsigned int * word, int wordLength, int index);

  // (used in opt polynomial functions only: for precomputing to lookup table)
  // generates value of function based on inputs
  byte timage_by_inputs(byte *inTerms, int numTerms,
			const map<int,int> &optFindTerm);

 public:
  //constructor
  Func(const string & iStr, int iShiftSize, bool opt);

  //destructor
  ~Func();

  //print
  void print(ofstream & fout);

  //return image of word x
  void image(byte *word, int wordLength, byte *output);

  //return image of word x
  void image(unsigned int * word, int wordLength, unsigned int *output,
	     unsigned int blocks);

  //return true if this is an opt polynomial function
  bool isOpt();
};

#endif




