/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * RecNode
 * A record node.  Stores information for all the runs for a given period.
 *
 * Written by: Bryant Lee
 * Date: 11/4/04
 */

#include "RecNode.h"

#include <map>

//constructor
RecNode::RecNode(unsigned int icPeriod, unsigned long long iNumTrials) {
  currPeriod = icPeriod;
  sumPeriod = 0;
  sumPreperiod = 0;
  numPeriodic = 0;
  numTrials = iNumTrials; 
  largestorbit = 0;

  //for FProbPeriod: pending flag says that this RecNode is not filled in yet
  // which is helpful in case of a crash
  //for FPeriod and FDense: this is not used
  pending = true;
}

//recordOrbit
void RecNode::recordOrbit(unsigned long long orbit) {
  map<unsigned long long, unsigned long long>::iterator mult;

  if((mult = orbitMap.find(orbit)) != orbitMap.end()) {
    mult->second++;
  }
  else {
    orbitMap.insert(pair<unsigned long long, unsigned long long>(orbit,1));
  }
}

//recordperiod
void RecNode::recordPeriod(unsigned long long period,
			   unsigned long long preperiod) {
  map<unsigned long long, unsigned long long>::iterator mult;

  if(period > largestorbit)
    largestorbit = period;

  sumPeriod += period;
  sumPreperiod += preperiod;

  if((mult = periodMap.find(period)) != periodMap.end()) {
    mult->second++;
  }
  else {
    periodMap.insert(pair<unsigned long long, unsigned long long>(period,1));
  }

  if((mult = preperiodMap.find(preperiod)) != preperiodMap.end()) {
    mult->second++;
  }
  else {
    preperiodMap.insert(pair<unsigned long long,unsigned long long>(preperiod,1));
  }
}

//recordPeriodicPeriod
void RecNode::recordPeriodicPeriod(unsigned long long period) {
  map<unsigned long long,unsigned long long>::iterator mult;

  if((mult = periodicPeriodMap.find(period)) != periodicPeriodMap.end()) {
    mult->second++;
  }
  else {
    periodicPeriodMap.insert(pair<unsigned long long,unsigned long long>(period,1));
  }
}

//fractionperiodic
double RecNode::fractionPeriodic() {
  return ((double) numPeriodic)/((double) numTrials);
}

//numnonperiodic
unsigned long long RecNode::numNonPeriodic() {
  return numTrials - numPeriodic;
}

//avgperiod
double RecNode::avgPeriod() {
  return ((double) sumPeriod)/((double) numTrials);
}

//avgpreperiod
double RecNode::avgPreperiod() {
  return ((double) sumPreperiod)/((double) numTrials);
}

//maxpreperiod
double RecNode::maxPreperiod() {
  map<unsigned long long, unsigned long long>::const_reverse_iterator rit;
  
  rit = preperiodMap.rbegin();
  if(rit !=
     (map<unsigned long long, unsigned long long>::const_reverse_iterator)
     preperiodMap.rend())
    return rit->first;
  else
    return 0;
}

//max period
double RecNode::maxPeriod() {
  map<unsigned long long,unsigned long long>::const_reverse_iterator rit;
  
  rit = periodMap.rbegin();
  if(rit !=
     (map<unsigned long long,unsigned long long>::const_reverse_iterator)
     periodMap.rend())
    return rit->first;
  else
    return 0;
}




