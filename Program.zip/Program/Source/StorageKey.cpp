/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FPeriod.
 *
 * FPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * StorageKey
 * Node with a word member.  Comparisons are allowed and are according
 * to lexicographic order of the words.
 *
 * Written by: Bryant Lee
 * Date: 11/4/04
 */

#include "StorageKey.h"
#include "StringOps.h"

//no argument constructor
StorageKey::StorageKey() {
  word = NULL;
  wordLength = 0;
}

//primary constructor
StorageKey::StorageKey(byte *inWord, unsigned int inWordLength) {
  unsigned int i = 0;

  wordLength = inWordLength;
  word = new byte[wordLength];

  //copy
  for(i = 0; i < wordLength; i++) {
    word[i] = inWord[i];
  }
}

//copy constructor
StorageKey::StorageKey(const StorageKey &m) {
  word = NULL;
  wordLength = 0;

  operator=(m);
}

//destructor
StorageKey::~StorageKey() {
  delete[] word;
}

//operator =
const StorageKey & StorageKey::operator=(const StorageKey &right) {
  unsigned int i = 0;
  
  delete[] word; //delete the old word

  wordLength = right.wordLength;
  word = new byte[wordLength];

  //copy
  for(i = 0; i < wordLength; i++) {
    word[i] = right.word[i];
  }

  return (*this);
}

//compare
//if > m, return positive
//if < m, return negative
//if == m, return 0
int StorageKey::compareTo(const StorageKey &m) const{
  unsigned int i = 0;
  int ret = 0;

  for(i = 0; i < wordLength; i++) {
    if(word[i] != m.word[i]) {
      ret = word[i] - m.word[i];
      break;
    }
  }

  return ret;
}

//relational operators
bool StorageKey::operator==(const StorageKey &right) const {
  return (compareTo(right) == 0);
}

bool StorageKey::operator!=(const StorageKey &right) const {
  return (compareTo(right) != 0);
}

bool StorageKey::operator<(const StorageKey &right) const {
  return (compareTo(right) < 0);
}

bool StorageKey::operator>(const StorageKey &right) const {
  return (compareTo(right) > 0);
}

bool StorageKey::operator<=(const StorageKey &right) const {
  return (compareTo(right) <= 0);
}

bool StorageKey::operator>=(const StorageKey &right) const {
  return (compareTo(right) >= 0);
}

//print
void StorageKey::print() const {
  printArray(word, wordLength);
  //cout << "Pointer: " << (unsigned int) word << "\n";
}






