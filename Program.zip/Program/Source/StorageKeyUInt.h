/*
 * Copyright (C) 2004 Bryant Lee
 *
 * This file is part of FProbPeriod.
 *
 * FProbPeriod is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FProbPeriod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FProbPeriod; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * StorageKeyUInt
 *
 * Each unsigned int represents a short string, for example when N = 2,
 * every bit represents a coordinate.  We need an array of UInts because
 * we might get larger than what 1 UInt can hold.
 *
 * Comparisons are allowed and are according
 * to lexicographic order of the words.
 *
 * Written by: Bryant Lee
 * Date: 9/19/05
 */

#ifndef STORAGE_KEY_UINT_H
#define STORAGE_KEY_UINT_H

extern int UINTSIZE;

class StorageKeyUInt {
 public:
  unsigned int * word;
 private:
  unsigned int wordLength;

  //compare
  //if > m, return positive
  //if < m, return negative
  //if == m, return 0
  int compareTo(const StorageKeyUInt &m) const {
    unsigned int i = 0;
    int ret = 0;

    for(i = 0; i < wordLength; i++) {
      if(word[i] != m.word[i]) {
	ret = word[i] - m.word[i];
	break;
      }
    }

    return ret;
  };

 public:
  //no argument constructor
  StorageKeyUInt() {
    word = NULL;
    wordLength = 0;
  };

  //primary constructor
  StorageKeyUInt(unsigned int *inWord, unsigned int inLength) {
    unsigned int i = 0;

    wordLength = inLength;
    word = new unsigned int[wordLength];
    
    //copy
    for(i = 0; i < wordLength; i++) {
      word[i] = inWord[i];
    }
  };

  //copy constructor
  StorageKeyUInt(const StorageKeyUInt &m) {
    word = NULL;
    wordLength = 0;

    operator=(m);
  };
  
  //destructor
  ~StorageKeyUInt() {
    delete[] word;
  };

  //operator =
  const StorageKeyUInt & operator=(const StorageKeyUInt &right) {
    unsigned int i = 0;
  
    delete[] word; //delete the old word
    
    wordLength = right.wordLength;
    word = new unsigned int[wordLength];
    
    //copy
    for(i = 0; i < wordLength; i++) {
      word[i] = right.word[i];
    }
    
    return (*this);
  };
 
  //relational operators
  bool operator==(const StorageKeyUInt &right) const {
    return (compareTo(right) == 0);
  };

  bool operator!=(const StorageKeyUInt &right) const {
    return (compareTo(right) != 0);
  };

  bool operator<(const StorageKeyUInt &right) const { 
    return (compareTo(right) < 0);
  };

  bool operator>(const StorageKeyUInt &right) const {
    return (compareTo(right) > 0);
  };

  bool operator<=(const StorageKeyUInt &right) const {
    return (compareTo(right) <= 0);
  };

  bool operator>=(const StorageKeyUInt &right) const {
    return (compareTo(right) >= 0);
  };

  //print
  void print() const {
    //NOTE: this will print the word, along with extraneous trailing 0's.
    printUIntArray(word, wordLength * UINTSIZE);
  };
};

#endif
